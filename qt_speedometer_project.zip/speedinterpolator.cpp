#include "speedinterpolator.h"

SpeedInterpolator::SpeedInterpolator(QObject *parent)
    : QObject(parent)
{
    m_timer.setInterval(16);
    connect(&m_timer, &QTimer::timeout,
            this, &SpeedInterpolator::update);
    m_timer.start();
}

double SpeedInterpolator::speed() const
{
    return m_currentSpeed;
}

void SpeedInterpolator::setTargetSpeed(double value)
{
    if (value < 0) value = 0;
    if (value > 240) value = 240;

    m_targetSpeed = (m_targetSpeed * 0.8) + (value * 0.2);
}

void SpeedInterpolator::update()
{
    double error = m_targetSpeed - m_currentSpeed;

    m_velocity += error * m_stiffness;
    m_velocity *= m_damping;

    m_currentSpeed += m_velocity;

    if (qAbs(m_velocity) < 0.001 &&
        qAbs(error) < 0.01)
    {
        m_currentSpeed = m_targetSpeed;
        m_velocity = 0.0;
    }

    emit speedChanged();
}