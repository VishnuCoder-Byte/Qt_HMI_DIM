#pragma once
#include <QObject>
#include <QTimer>

class SpeedInterpolator : public QObject
{
    Q_OBJECT
    Q_PROPERTY(double speed READ speed NOTIFY speedChanged)

public:
    explicit SpeedInterpolator(QObject *parent = nullptr);

    double speed() const;
    Q_INVOKABLE void setTargetSpeed(double value);

signals:
    void speedChanged();

private slots:
    void update();

private:
    QTimer m_timer;
    double m_currentSpeed = 0.0;
    double m_targetSpeed  = 0.0;
    double m_velocity     = 0.0;

    double m_stiffness = 0.12;
    double m_damping   = 0.88;
};