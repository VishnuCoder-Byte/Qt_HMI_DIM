#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include "speedinterpolator.h"

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    SpeedInterpolator speed;

    QQmlApplicationEngine engine;
    engine.rootContext()->setContextProperty("SpeedBackend", &speed);

    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));

    return app.exec();
}