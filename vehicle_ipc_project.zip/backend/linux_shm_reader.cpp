#include "linux_shm_reader.h"

#define SHM_NAME "/vehicle_shm"

bool LinuxShmReader::init()
{
    m_fd = shm_open(SHM_NAME, O_RDONLY, 0666);
    if (m_fd < 0)
        return false;

    m_ptr = (VehicleData*)mmap(
        nullptr,
        sizeof(VehicleData),
        PROT_READ,
        MAP_SHARED,
        m_fd,
        0
    );

    return m_ptr != MAP_FAILED;
}

bool LinuxShmReader::readData(VehicleData& data)
{
    if (!m_ptr)
        return false;

    data = *m_ptr;
    return true;
}
