#include "qnx_pps_reader.h"
#include <sstream>

bool QnxPpsReader::init()
{
    m_file.open("/pps/vehicle/data");
    return m_file.is_open();
}

bool QnxPpsReader::readData(VehicleData& data)
{
    if (!m_file.is_open())
        return false;

    m_file.clear();
    m_file.seekg(0);

    std::string line;

    while (std::getline(m_file, line))
    {
        std::istringstream ss(line);
        std::string key, value;

        if (std::getline(ss, key, '=') &&
            std::getline(ss, value))
        {
            if (key == "speed")
                data.speed = std::stoi(value);
            else if (key == "rpm")
                data.rpm = std::stoi(value);
            else if (key == "odo")
                data.odometer = std::stoi(value);
        }
    }

    return true;
}
