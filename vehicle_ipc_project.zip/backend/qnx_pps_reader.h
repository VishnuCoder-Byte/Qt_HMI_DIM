#pragma once
#include "../common/ipc_interface.h"
#include <fstream>

class QnxPpsReader : public IIPCReader
{
public:
    bool init() override;
    bool readData(VehicleData& data) override;

private:
    std::ifstream m_file;
};
