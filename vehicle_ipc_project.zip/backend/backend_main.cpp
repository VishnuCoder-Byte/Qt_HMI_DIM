#include <iostream>
#include <memory>
#include <thread>

#include "../common/ipc_interface.h"

#ifdef __QNXNTO__
#include "qnx_pps_reader.h"
#else
#include "linux_shm_reader.h"
#endif

int main()
{
    std::unique_ptr<IIPCReader> reader;

#ifdef __QNXNTO__
    reader = std::make_unique<QnxPpsReader>();
#else
    reader = std::make_unique<LinuxShmReader>();
#endif

    if (!reader->init())
    {
        std::cerr << "IPC init failed\n";
        return -1;
    }

    VehicleData data{};

    while (true)
    {
        if (reader->readData(data))
        {
            std::cout
                << "Speed: " << data.speed
                << " RPM: " << data.rpm
                << " ODO: " << data.odometer
                << std::endl;
        }

        std::this_thread::sleep_for(
            std::chrono::milliseconds(200)
        );
    }
}
