#pragma once
#include "../common/ipc_interface.h"
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>

class LinuxShmReader : public IIPCReader
{
public:
    bool init() override;
    bool readData(VehicleData& data) override;

private:
    int m_fd = -1;
    VehicleData* m_ptr = nullptr;
};
