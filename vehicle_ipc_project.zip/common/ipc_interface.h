#pragma once

struct VehicleData
{
    int speed;
    int rpm;
    int odometer;
};

class IIPCReader
{
public:
    virtual ~IIPCReader() = default;
    virtual bool init() = 0;
    virtual bool readData(VehicleData& data) = 0;
};
