#include <fstream>
#include <thread>
#include <chrono>

int main()
{
    std::ofstream file("/pps/vehicle/data");

    int speed = 0;
    int rpm = 1000;
    int odo = 10000;

    while (true)
    {
        file.seekp(0);

        file <<
            "speed=" << speed << "\n"
            "rpm=" << rpm << "\n"
            "odo=" << odo << "\n";

        file.flush();

        speed = (speed + 5) % 180;
        rpm   = 1000 + speed * 40;
        odo++;

        std::this_thread::sleep_for(
            std::chrono::milliseconds(200)
        );
    }
}
