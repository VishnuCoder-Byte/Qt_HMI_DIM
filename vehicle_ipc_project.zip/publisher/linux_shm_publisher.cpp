#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <thread>
#include <chrono>

#include "../common/ipc_interface.h"

#define SHM_NAME "/vehicle_shm"

int main()
{
    int fd = shm_open(
        SHM_NAME,
        O_CREAT | O_RDWR,
        0666
    );

    ftruncate(fd, sizeof(VehicleData));

    auto* ptr = (VehicleData*)mmap(
        nullptr,
        sizeof(VehicleData),
        PROT_WRITE,
        MAP_SHARED,
        fd,
        0
    );

    int speed = 0;

    while (true)
    {
        ptr->speed = speed;
        ptr->rpm = 1000 + speed * 40;
        ptr->odometer++;

        speed = (speed + 3) % 160;

        std::this_thread::sleep_for(
            std::chrono::milliseconds(200)
        );
    }
}
